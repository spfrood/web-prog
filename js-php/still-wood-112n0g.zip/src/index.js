import Phaser from "phaser";
const config = {
  type: Phaser.AUTO,
  width: 400,
  height: 300,
  backgroundColor: "#000",
  parent: "app",
  // whenever the 'this' is used it refers to scene
  scene: {
    preload: preload,
    create: create,
    update: update
  },
  physics: {
    default: "arcade",
    arcade: {
      //debug: true
    }
  }
};

new Phaser.Game(config);

function preload() {
  this.load.baseURL = "https://labs.phaser.io/assets/";
  this.load.crossOrigin = "anonymous";
  // Tiled is a popular free tool to make the atlas and json file
  this.load.atlas(
    // the name of the atlas is the first key... in this case 'assets' because it contains all the art assets
    "assets",
    // file that holds all the images
    "games/breakout/breakout.png",
    // json file holds the image map information on the image file with the grapic assets
    "games/breakout/breakout.json"
  );
}

function create() {
  // add a sprite to the game screen drawing from the assets file
  // The first numbers are x and y coordinates. Asssets is the name of the atlas
  // then the name of the image from the json file for the atlas
  let ball = this.physics.add.sprite(200, 200, "assets", "ball1");
  // Set the velocity of the ball sprit to make it move on the screen
  ball
    .setVelocity(50, 100)
    .setCollideWorldBounds(true)
    .setBounce(1);
  // add paddle to the game field. Using this instead of let creates the paddle in the scene and it
  // can be accessed outside of the create function (ie in the update function)
  this.paddle = this.physics.add
    .sprite(200, 280, "assets", "paddle1")
    .setImmovable(true);
  // add colliders so paddle and ball can interact
  this.physics.add.collider(this.paddle, ball);
  // creating the blocks. Using object literal notation
  this.bricks = this.physics.add.group({
    key: "assets",
    // name of image from the json file for assets
    frame: ["red1", "blue1"],
    // specify how many times to copy the asset
    frameQuantity: 8,
    // specify how to place the assets in the grid
    gridAlign: {
      // offset for x and y of first brick center
      x: 100,
      y: 50,
      width: 4,
      height: 4,
      cellWidth: 64,
      cellHeight: 32
    },
    // make it so bricks don't move around when hit by the ball
    immovable: true
  });
  this.physics.add.collider(this.bricks, ball, brickhit);
}
function update() {
  this.paddle.x = this.input.x;
}

// what happens when the ball hits a brick
function brickhit(ball, brick) {
  brick.destroy();
}
